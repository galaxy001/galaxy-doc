Silverlight Screen Saver install
(for PC : Windows 7/Vista/ XP)

Please unzip a file first.
open "hikaru" folder, then click "hikaru.scr" by right mouse key.
Click the "install" item on the menu list.
Follow the Windows screensaver setting process to complete it.

Screen saver has been installed sucessfully.
   