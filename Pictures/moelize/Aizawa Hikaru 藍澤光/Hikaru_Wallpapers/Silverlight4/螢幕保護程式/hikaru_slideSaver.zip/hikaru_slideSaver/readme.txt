Silverlight Screen Saver install
(for Mac : Mac OS X 10.4 or later)

Please unzip a file first, 
Double click "hikaru_slideSaver" folder.
Then follow the install wizard information to process this installration.
 
Screen saver has been installed successfully.
   